%The code is conducted on Ubuntu system equipped with an Intel Xeon Gold 6248R CPU, 256GB of RAM, 
% and two NVIDIA GeForce RTX 3090 GPUs (24GB each). 
%The experimental results on other devices may vary.


clear all

load("webkb_mtv.mat");

K = multi_view_pca_unified_k(X,size(unique(gt),1));
alpha = 80;
beta = 1;
gamma = 1500;
Zstar = DFBASR(X, K, alpha, beta, gamma);
Clus = Ng_SpectralClustering(Zstar,size(unique(gt),1)); %
result = EvaluationMetrics(gt,Clus);
fprintf("ACC:%5.4f,NMI:%5.4f,alpha:%5.4f,beta:%5.4f,gamma:%5.4f\n",result(1), result(2), alpha, beta, gamma);


